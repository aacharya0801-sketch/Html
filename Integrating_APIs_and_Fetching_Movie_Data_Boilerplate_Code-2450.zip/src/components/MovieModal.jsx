// ════════════════════════════════════════════════════════════════════════════
// MovieModal.jsx — Full-screen movie detail popup (NEW in Lesson 4)
// ════════════════════════════════════════════════════════════════════════════

import { useCallback } from 'react';
import { useApp } from '../context/AppContext';

// ──────────────────── LESSON 4 ────────────────────
// Build the full movie detail modal.
// Get selectedMovie and setShowModal from useApp().
// Show: poster, title, year, rating, plot, director, actors, IMDb link.
// Close when the backdrop is clicked or the X button is pressed.



// ──────────────────── END ─────────────────────────
